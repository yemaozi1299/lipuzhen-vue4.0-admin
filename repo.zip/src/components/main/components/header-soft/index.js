import headerSoft from './headerSoft.vue'
export default headerSoft
