import Buttons from './buttons.vue'
export default Buttons
