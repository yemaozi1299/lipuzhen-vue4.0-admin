import Admin from './admin.vue'
export default Admin
