import infoCard from './info-card.vue'
export default infoCard
