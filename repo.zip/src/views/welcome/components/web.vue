<template>
    <div>web</div>
</template>

<script>
export default {

}
</script>

<style>
</style>