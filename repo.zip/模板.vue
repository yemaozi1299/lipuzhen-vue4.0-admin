<template>
	<div>
		
	</div>
</template>

<script type="text/javascript">
	export default {
		name:"",
		props:{
			
		},
		data(){
			return{

			}
		}
	}

</script>

<style lang="stylus" rel="stylesheet/stylus">
	
</style>